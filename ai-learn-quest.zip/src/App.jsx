import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Amplify } from "aws-amplify";
import awsExports from "./aws-exports";
import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";

import Home from "./pages/Home";
import Quiz from "./pages/Quiz";
import Profile from "./pages/Profile";

Amplify.configure(awsExports);

function App({ signOut, user }) {
  return (
    <Router>
      <div className="p-4">
        <header className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold">AI Learn Quest</h1>
          <button onClick={signOut} className="bg-red-500 text-white px-3 py-1 rounded">Sign out</button>
        </header>
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/profile" element={<Profile user={user} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default withAuthenticator(App);