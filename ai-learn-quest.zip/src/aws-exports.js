// Replace with your actual AWS Amplify config
const awsExports = {
  aws_project_region: "us-east-1",
  aws_cognito_region: "us-east-1",
  aws_user_pools_id: "us-east-1_Example",
  aws_user_pools_web_client_id: "exampleclientid123",
  oauth: {}
};
export default awsExports;