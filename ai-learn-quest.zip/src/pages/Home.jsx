import React from "react";
import { Link } from "react-router-dom";

function Home({ user }) {
  return (
    <div className="text-center">
      <h2 className="text-2xl font-bold mb-4">Welcome, {user.username}!</h2>
      <p>Select a topic to begin your AI journey:</p>
      <div className="mt-4 space-y-2">
        <Link to="/quiz" className="inline-block bg-green-500 text-white px-4 py-2 rounded">Start Quiz</Link>
      </div>
    </div>
  );
}

export default Home;