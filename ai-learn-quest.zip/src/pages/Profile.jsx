import React from "react";

function Profile({ user }) {
  return (
    <div className="text-center">
      <h2 className="text-2xl font-bold mb-4">Your Profile</h2>
      <p>Username: {user.username}</p>
      <p className="mt-4">XP: 0 (demo)</p>
      <p>Streak: 0 days</p>
      <p>Badges: None yet</p>
    </div>
  );
}

export default Profile;