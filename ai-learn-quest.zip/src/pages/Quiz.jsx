import React, { useState } from "react";

const questions = [
  {
    question: "What is AI?",
    options: ["Artificial Ice", "Awesome Intelligence", "Artificial Intelligence", "Animal Interaction"],
    answer: "Artificial Intelligence",
  },
  {
    question: "Which of these is an AI assistant?",
    options: ["Alexa", "Microwave", "Notebook", "Chair"],
    answer: "Alexa",
  },
];

function Quiz() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (option) => {
    if (option === questions[current].answer) {
      setScore(score + 10);
    }
    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      setShowResult(true);
    }
  };

  if (showResult) {
    return (
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Quiz Completed!</h2>
        <p className="text-lg">Your Score: {score} XP</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-lg font-semibold mb-2">Question {current + 1}</h2>
      <p className="mb-4">{questions[current].question}</p>
      <div className="space-y-2">
        {questions[current].options.map((option, idx) => (
          <button
            key={idx}
            onClick={() => handleAnswer(option)}
            className="block w-full bg-blue-100 hover:bg-blue-300 text-left px-4 py-2 rounded"
          >
            {option}
          </button>
        ))}
      </div>
      <div className="mt-6 text-sm">XP: {score}</div>
    </div>
  );
}

export default Quiz;